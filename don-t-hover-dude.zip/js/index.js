document.getElementById("hover").onmouseover =  function(){
  alert(HEY WHAT DID I SAY!!!);
};